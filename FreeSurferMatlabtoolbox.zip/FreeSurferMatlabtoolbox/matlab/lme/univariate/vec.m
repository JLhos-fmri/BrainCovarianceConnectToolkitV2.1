function h = vec(H)
% h = vec(H)
% 
% Vectorize matrix.
%
% H: Matrix
%
% $Revision: 1.2 $  $Date: 2015/01/06 17:14:57 $
% Original Author: Jorge Luis Bernal Rusiel 
% CVS Revision Info:
%    $Author: mreuter $
%    $Date: 2015/01/06 17:14:57 $
%    $Revision: 1.2 $
%
    
h = H(:);
   